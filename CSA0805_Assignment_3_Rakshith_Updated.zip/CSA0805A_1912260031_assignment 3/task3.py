complaints = {
    "Water": 12,
    "Electricity": 8,
    "Road": 15,
    "Garbage": 5
}

for category, count in complaints.items():
    print(category, ":", count)

highest = max(complaints, key=complaints.get)
print("Most complaints:", highest)
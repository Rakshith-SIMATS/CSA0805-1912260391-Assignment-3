readings = [18, 25, 32, 15, 40, 28]

high_readings = [value for value in readings if value > 30]

print("All readings:", readings)
print("Readings above 30:", high_readings)
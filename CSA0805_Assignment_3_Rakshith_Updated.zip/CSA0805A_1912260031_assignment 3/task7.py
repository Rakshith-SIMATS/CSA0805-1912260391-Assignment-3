contacts1 = {
    "Arun": "9876543210",
    "Bala": "9876501234"
}

contacts2 = {
    "Chitra": "9876512340",
    "Bala": "9999911111"
}

contacts = contacts1.copy()
contacts.update(contacts2)

print("Merged contacts:", contacts)